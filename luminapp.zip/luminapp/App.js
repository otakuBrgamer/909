import *as React from 'react';
import InitialScreen from './screens/InicialScreen';
import LoginScreen from './screens/LoginScreen'
import PasswordRecovery from './screens/Pass'

export default function App(){
  return<PasswordRecovery />
}